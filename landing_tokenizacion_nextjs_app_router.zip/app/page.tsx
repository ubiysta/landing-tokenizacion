
export default function Page() {
  return (
    <div style={{padding: 40}}>
      <h1 style={{fontSize: 32, fontWeight: 'bold'}}>Landing Tokenización – Placeholder</h1>
      <p>Tu landing completa se insertará aquí cuando me digas “sí, reemplázalo”.</p>
    </div>
  );
}
